

% Define filter parameters
order = 5;          % Filter order
cutoff_freq = 5;    % Cutoff frequency in Hz

% Calculate filter coefficients
[b, a] = butter(order, cutoff_freq/(fs/2), 'low');

% Create a frequency vector
f = logspace(-1, 1, 50); % Frequency range from 0.1 Hz to 10 Hz

% Calculate the frequency response of the filter
H = freqz(b, a, 2*pi*f, fs);

% Plot the Bode plot
figure;
subplot(2,1,1); % Magnitude plot
semilogx(f, 20*log10(abs(H)));
title('Magnitude Response');
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
grid on;

subplot(2,1,2); % Phase plot
semilogx(f, angle(H)*180/pi);
title('Phase Response');
xlabel('Frequency (Hz)');
ylabel('Phase (degrees)');
grid on;

% Adjust plot settings
set(gcf, 'Color', 'w');

