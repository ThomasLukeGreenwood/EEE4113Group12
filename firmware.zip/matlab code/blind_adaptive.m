function create()
    t = 0.001:0.001:5;
    A = 5 * ones(size(t)) + 0.9*randn(size(t)); % Noisy input signal

    [Est,error] = adaptive_filter(A);

    %subplot(3,1,1), plot(t, A, t, 5*ones(size(t)), 'r--'); % Plot noisy input signal and DC value
    %title('Noisy Input Signal');
    %ylabel('Weight(kg)'); % Add y-axis label
    %xlabel('Time(s)'); % Add x-axis label
    %legend('Noisy Input Signal', 'DC Value');
    
    subplot(1,1,1), plot(t, Est, t, 5*ones(size(t)), 'r--'); % Plot filtered output and DC value
    title('Filtered Output');
    ylabel('Weight(kg)'); % Add y-axis label
    xlabel('Time(s)'); % Add x-axis label
    legend('Filtered Output', 'DC Value');

    %subplot(3,1,3), plot(t, error,t, 5*ones(size(t)), 'r--'); % Plot filtered output and DC value
    %title('Error');
    %ylabel('Weight(kg)'); % Add y-axis label
    %xlabel('Time(s)'); % Add x-axis label
    %legend('Error Output', 'DC Value');

    make_bode(Est);

end

function [Est, error] = adaptive_filter(input_signal)
    M = 20; % Filter order
    w = zeros(1, M); % Initial filter coefficients
    mu = 0.001; % Adaptation step size
    n = length(input_signal);
    error=[];

    Est = zeros(size(input_signal));
    error= zeros(size(input_signal));
    for i =65:n
        % Estimate output using current filter coefficients
        Est(i) = w * input_signal(i:-1:i-M+1)';
        
        % Update filter coefficients using the LMS algorithm with regularization
        error(i)= input_signal(i) - Est(i);
        w = w + mu * error(i) * input_signal(i:-1:i-M+1) + 0.01 * w; % Regularization term
        
        % Ensure stability by normalizing filter coefficients
        w = w / norm(w);
    end
end

function make_bode(signal)

input_signal =signal;
fs=2000;
% Compute Fourier Transform
N = length(input_signal);
freq = (0:N-1)*(fs/N);
fourier_transform = fft(input_signal);


% Plot Fourier transform magnitude spectrum
figure;
plot(freq, abs(fourier_transform));
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Fourier Transform Magnitude Spectrum');
end
