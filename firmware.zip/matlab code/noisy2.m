cut_off = 1000;
order = 4;  % Adjust the filter order based on your requirements
fs = 200e3;
ts = 1/fs;
dt = 0:ts:3e-3-ts;

f1 = 900;
f2 = f1 * 120;
f3 = f1 * 971;

x1 = 40 * sin(2 * pi * f1 * dt);
x2 = 6 * sin(2 * pi * f2 * dt);
x3 = 9 * sin(2 * pi * f3 * dt);

input = x1 + x2 + x3;

% Design the Butterworth low-pass filter
[b, a] = butter(order, cut_off/(fs/2), 'low');



% Apply the filter to the input signal
filteredOutput = filter(b, a, input);

% Plot the input signal and the filtered output
figure;
plot(dt, input, 'b', 'LineWidth', 1.5);
hold on;
plot(dt, filteredOutput, 'r', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Amplitude');
title('Original Input Signal vs. Filtered Output');
legend('Original Input', 'Filtered Output');
grid on;
