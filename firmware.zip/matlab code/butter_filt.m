function create()
    % Define filter parameters
    cut_off = 5;
    orders = 5;  % Adjust the filter order based on your requirements
    fs = 2000;  % Sampling frequency
    
    bs = [0.00024132, 0.00048264, 0.00024132];
    as= [1.95558189, -0.95654717];


   % float b[] = {0.00024132, 0.00048264, 0.00024132};
%float a[] = {1.95558189, -0.95654717};

    % Generate input signal
    f1 = 2;
    f2 = f1 * 19;
    f3 = f1 * 14;
    ts = 1/fs;  % Sampling interval
    dt = 0:ts:1;  % Time vector
    x1 = 5 * ones(size(ts));
    x2 = 6 * sin(2 * pi * f2 * dt);
    x3 = 9 * sin(2 * pi * f3 * dt);
    input_signal = x1 + x2 + x3;

   

    % Design the Butterworth low-pass filter
    [b, a] = butter(orders, cut_off/(fs/2), 'low');

    filtered_signal = my_filter(b, a, input_signal);
    seconds=filter(b,a, input_signal);
    
    % Plot Bode plot
   figure;
   bode(tf(1,[1, 1/fs])); % Bode plot of a first-order low-pass filter

    % Plot results
    disp(as);
    disp(bs);

    figure;
    subplot(3,1,1);
    plot(dt, input_signal);
    title('Input Signal');
    xlabel('Time (s)');
    ylabel('Weight (kg)');
    subplot(3,1,2);
    plot(dt, filtered_signal);
    title('Filtered Signal');
    xlabel('Time (s)');
    ylabel('Weight (kg)');
    subplot(3,1,3);
    plot(dt, seconds);
    title('Golden measure');
    xlabel('Time (s)');
    ylabel('Weight (kg)');
    
end



function filtered_signal = my_filter(b, a, input_signal)

    
    % Length of input signal and filter coefficients
    len_input = length(input_signal);
    len_b = length(b);
    len_a = length(a);
    
    % Initialize filtered signal
    filtered_signal = zeros(size(input_signal));
    
    % Perform filtering
    for n = 1:len_input
        % Apply filter
        for k = 1:min(n, len_b)
            filtered_signal(n) = filtered_signal(n) + b(k) * input_signal(n - k + 1);
        end
        for m = 2:min(n, len_a)
            filtered_signal(n) = filtered_signal(n) - a(m) * filtered_signal(n - m + 1);
        end
    end
end


