t = 0.001:0.001:1;
D = 5 * ones(size(t)); % Desired signal is a stable DC reading of 5

n = length(D);
input_signal =D(1:n) + 0.9*randn(1, n);

% Compute Fourier Transform
N = length(input_signal);
freq = (0:N-1)*(fs/N);
fourier_transform = fft(input_signal);


% Plot Fourier transform magnitude spectrum
figure;
plot(freq, abs(fourier_transform));
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Fourier Transform Magnitude Spectrum');
