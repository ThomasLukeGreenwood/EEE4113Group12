function create()
    t = 0.001:0.001:1;
    D = 5 * ones(size(t)); % Desired signal is a stable DC reading of 5

    n = length(D);
    A = D(1:n) + 0.9*randn(1, n);

    Est = adaptive_filter(A, D, n);

    subplot(3,1,1), plot(D);
    title('Desired');
    xlabel('Time (s)');
    ylabel('Weight (kg)');


    subplot(3,1,2), plot(A);
    title('Noisy input signal');
    xlabel('Time (s)');
    ylabel('Weight (kg)');


    subplot(3,1,3), plot(Est);
    title('Filtered');
    xlabel('Time (s)');
    ylabel('Weight (kg)');

    make_bode(Est);
end

function Est = adaptive_filter(noisy, desired, n)
    D = desired;
    A = noisy;
    M = 65;
    w = zeros(1, M);
    wi = zeros(1, M);
    E = [];
    mu = 0.0005;

    for i = M:n
        E(i) = D(i) - wi*A(i:-1:i-M+1)';
        wi = wi + 2*mu*E(i)*A(i:-1:i-M+1);
    end

    Est = zeros(n, 1);
    for i = M:n
        j = A(i:-1:i-M+1);
        Est(i) = (wi)*(j)';
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function make_bode(signal)

input_signal =signal;
fs=2000;
% Compute Fourier Transform
N = length(input_signal);
freq = (0:N-1)*(fs/N);
fourier_transform = fft(input_signal);


% Plot Fourier transform magnitude spectrum
figure;
plot(freq, abs(fourier_transform));
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Fourier Transform Magnitude Spectrum');
end